import asyncio
import pandas as pd
from datetime import datetime

# ---- IMPORT YOUR REAL FUNCTIONS HERE ----
from analytics.fundamentals import get_bulk_fundamentals
from analytics.risk import get_bulk_risk
from analytics.momentum import get_bulk_momentum
from analytics.sentiment import get_bulk_sentiment
from analytics.llm import llm_score


# ---------------------------------------------------------
# MASTER SCORE PIPELINE FOR A SINGLE HISTORICAL DATE
# ---------------------------------------------------------
async def score_date(tickers: list, date_str: str):
    """
    Computes model scores for a specific historical date.
    """

    # --- 1. Load all components (ASYNC) ---
    fundamentals_task = get_bulk_fundamentals(tickers, date_override=date_str)
    risk_task         = get_bulk_risk(tickers)
    momentum_task     = get_bulk_momentum(tickers, date_override=date_str)
    sentiment_task    = get_bulk_sentiment(tickers, date_override=date_str)

    fundamentals, risk_data, momentum_data, sentiment_data = await asyncio.gather(
        fundamentals_task,
        risk_task,
        momentum_task,
        sentiment_task
    )

    # --- 2. Convert risk + momentum into a single DataFrame ---
    risk_df = pd.DataFrame(risk_data)
    momentum_df = pd.DataFrame(momentum_data)

    risk_df = risk_df.set_index("ticker")
    momentum_df = momentum_df.set_index("ticker")

    # Combined risk/momentum pillars (your original format)
    risk_momentum = pd.concat([risk_df, momentum_df], axis=1)

    # --- 3. Convert fundamentals into value + quality ---
    fundamentals_df = pd.DataFrame(fundamentals).set_index("ticker")

    # You already compute these pillars inside your model normally
    value_cols = ["pe", "pb", "ps", "ev_ebitda"]
    quality_cols = ["roe", "roa", "gross_margin", "operating_margin"]

    fundamentals_df["value_score"] = fundamentals_df[value_cols].mean(axis=1)
    fundamentals_df["quality_score"] = fundamentals_df[quality_cols].mean(axis=1)

    value_quality = fundamentals_df[["value_score", "quality_score"]]

    # --- 4. Sentiment ---
    sentiment_df = pd.DataFrame(sentiment_data).set_index("ticker")

    # --- 5. Merge all components ---
    df = value_quality \
        .join(risk_momentum, how="inner") \
        .join(sentiment_df, how="left")

    df = df.fillna(0)  # safety

    # --- 6. Apply pillar weights ---
    w_value = 0.25
    w_quality = 0.25
    w_risk = 0.20
    w_momentum = 0.20
    w_sentiment = 0.10

    df["agg_pillars"] = (
        w_value * df["value_score"] +
        w_quality * df["quality_score"] +
        w_risk * df["risk_score"] +
        w_momentum * df["momentum_score"] +
        w_sentiment * df["sentiment_score"]
    )

    # --- 7. Add LLM score (your llm5 model) ---
    llm_scores = await llm_score(df, date_str)
    df["llm5"] = llm_scores

    df["final5"] = 0.9 * df["agg_pillars"] + 0.1 * df["llm5"]

    return df


# ---------------------------------------------------------
# BACKTESTER ENTRYPOINT
# ---------------------------------------------------------
def run_backtest(date_str: str, tickers: list):
    """
    Runs the full backtest for a single historical date.
    Returns a DataFrame with all scores + final buy score.
    """
    print(f"Scoring {len(tickers)} stocks for historical date: {date_str}")

    df = asyncio.run(score_date(tickers, date_str))

    df = df.sort_values("final5", ascending=False)
    return df
